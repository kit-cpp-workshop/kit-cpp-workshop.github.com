var searchData=
[
  ['color24',['Color24',['../structbmp_1_1Color24.html',1,'bmp']]]
];
