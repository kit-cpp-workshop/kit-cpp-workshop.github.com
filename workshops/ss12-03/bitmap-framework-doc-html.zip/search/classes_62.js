var searchData=
[
  ['batchbitmap24',['BatchBitmap24',['../classbmp_1_1BatchBitmap24.html',1,'bmp']]],
  ['bitmap24',['Bitmap24',['../classbmp_1_1Bitmap24.html',1,'bmp']]]
];
