var searchData=
[
  ['convert',['convert',['../classbmp_1_1AbsoluteCoordinate.html#aedf1c425cf7c8d490d6dcdd2318b0a37',1,'bmp::AbsoluteCoordinate::convert()'],['../classbmp_1_1RelativeCoordinate.html#aabe3253c6377cf715de3e665745a8fe5',1,'bmp::RelativeCoordinate::convert()']]]
];
