var searchData=
[
  ['getcurrentcolor',['getCurrentColor',['../classbmp_1_1BatchBitmap24.html#aef29ad3119361c65dc54bb5d20992ef2',1,'bmp::BatchBitmap24']]],
  ['getcurrentpos',['getCurrentPos',['../classbmp_1_1BatchBitmap24.html#ad0e8a2282ee27f15eb65ca9ff6504714',1,'bmp::BatchBitmap24']]],
  ['getheight',['getHeight',['../classbmp_1_1Bitmap24.html#aa7ceeca017c1aaed9ee970b96ccec3e1',1,'bmp::Bitmap24']]],
  ['getpixel',['getPixel',['../classbmp_1_1Bitmap24.html#aceb42a3c09a8d54984abed5a52ba6fd8',1,'bmp::Bitmap24']]],
  ['getpixelbycoord',['getPixelByCoord',['../classbmp_1_1BatchBitmap24.html#a2c3759ce9fb053e03c41adc184508d3a',1,'bmp::BatchBitmap24']]],
  ['getwidth',['getWidth',['../classbmp_1_1Bitmap24.html#a6da66aba56ac44d2a1d65495697297b9',1,'bmp::Bitmap24']]],
  ['getx',['getX',['../classbmp_1_1AbsoluteCoordinate.html#ac81f4d924a0d17e3bf5e36f8a12f5596',1,'bmp::AbsoluteCoordinate::getX()'],['../classbmp_1_1RelativeCoordinate.html#aae9eee35325bb1021296ff028b3a9724',1,'bmp::RelativeCoordinate::getX()']]],
  ['gety',['getY',['../classbmp_1_1AbsoluteCoordinate.html#ac443e8025b2ad45aad8a3ef08acfe326',1,'bmp::AbsoluteCoordinate::getY()'],['../classbmp_1_1RelativeCoordinate.html#a7a30f5426463a7a658c9183532e0f24a',1,'bmp::RelativeCoordinate::getY()']]]
];
