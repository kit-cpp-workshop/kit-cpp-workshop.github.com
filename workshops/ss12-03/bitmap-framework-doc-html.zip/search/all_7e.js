var searchData=
[
  ['_7ebatchbitmap24',['~BatchBitmap24',['../classbmp_1_1BatchBitmap24.html#aa12fbc9e519dcbdecf225d72d84eadb5',1,'bmp::BatchBitmap24']]],
  ['_7ebitmap24',['~Bitmap24',['../classbmp_1_1Bitmap24.html#a0267d98de2fd1a05baf5292cd55ff167',1,'bmp::Bitmap24']]],
  ['_7eibatchdrawable',['~IBatchDrawable',['../classbmp_1_1IBatchDrawable.html#ad61c12d845f5719da259a1cbec5264dd',1,'bmp::IBatchDrawable']]]
];
