var searchData=
[
  ['batchbitmap24',['BatchBitmap24',['../classbmp_1_1BatchBitmap24.html#a33541a0174fb4ff54de0ccf06a5a2e57',1,'bmp::BatchBitmap24']]],
  ['bitmap24',['Bitmap24',['../classbmp_1_1Bitmap24.html#a59b60a48e66c7867b74212d17eed9514',1,'bmp::Bitmap24']]]
];
